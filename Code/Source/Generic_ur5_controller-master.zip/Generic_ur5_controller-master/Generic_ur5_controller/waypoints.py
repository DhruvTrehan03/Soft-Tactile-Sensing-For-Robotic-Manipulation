from math import pi

# home position
burt_homej = [-1.57255, -1.29794, -1.18718, -2.22769, 1.57521, -0.00545246]

# gripper tool centre points (tcp)
pincher_tcp = [0,0,0.142,0,0,0]
bluetack_tcp = [0,0,-0.215,0,0,0]
